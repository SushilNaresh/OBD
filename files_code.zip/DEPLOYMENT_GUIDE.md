# OBD CODE UPDATE DEPLOYMENT GUIDE
## Version 2.2.0 - Implementation of FIX #1, #2, #3

---

## WHAT'S BEEN UPDATED

### Files Modified (Updated versions provided)

| File | Original | Updated | Changes |
|------|----------|---------|---------|
| dispatcher.c | v2.1.0 | v2.2.0 (dispatcher_updated.c) | FIX #1: Ring buffer + 8 parser threads, FIX #2: Worker queue, FIX #3: SO_REUSEPORT multi-recv |
| worker.c | v2.0.6 | v2.1.0 (worker_updated.c) | FIX #2: Worker queue consumer + fallback to Unix socket |
| sip_engine.c | v2.0.9 | v2.1.0 (sip_engine_updated.c) | FIX #3: Compile-time limits + improved diagnostics |
| Makefile | (original) | v2.2.0 (Makefile_updated) | FIX #3: PJSUA limit flags, tuning parameters |
| obd.h | v2.0.7 | (unchanged) | No changes required |
| main.c | v2.0.6 | (unchanged) | No changes required |
| dedup.c | (original) | (unchanged) | No changes required |
| udp_report.c | (original) | (unchanged) | No changes required |

---

## DEPLOYMENT STEPS

### Step 1: Backup Current Code
```bash
cd /path/to/obd-project
git stash  # or make a backup branch
mkdir -p backups/v2.1.0
cp dispatcher.c backups/v2.1.0/
cp worker.c backups/v2.1.0/
cp sip_engine.c backups/v2.1.0/
cp Makefile backups/v2.1.0/
```

### Step 2: Replace Files
```bash
# Copy updated dispatcher.c
cp dispatcher_updated.c dispatcher.c

# Copy updated worker.c
cp worker_updated.c worker.c

# Copy updated sip_engine.c
cp sip_engine_updated.c sip_engine.c

# Copy updated Makefile
cp Makefile_updated Makefile
```

### Step 3: Verify File Structure
```bash
ls -la *.c *.h Makefile

# Expected:
# -rw-r--r-- main.c (unchanged)
# -rw-r--r-- dispatcher.c (updated, ~850 lines now vs 640)
# -rw-r--r-- worker.c (updated, ~280 lines now vs 202)
# -rw-r--r-- sip_engine.c (updated, ~900 lines now vs 860)
# -rw-r--r-- dedup.c (unchanged)
# -rw-r--r-- udp_report.c (unchanged)
# -rw-r--r-- obd.h (unchanged)
# -rw-r--r-- Makefile (updated)
```

### Step 4: Clean and Compile

**For 10K TPS capacity (100 workers × 100 calls):**
```bash
make clean
make tune OBD_NUM_WORKERS=100 OBD_CALLS_PER_WORKER=100

# Expected output:
# Compile dispatcher.c with ring buffer (4096 slots), 8 parser threads, 4 recv threads
# Compile worker.c with queue consumer
# Compile sip_engine.c with PJSUA_MAX_ACC=10000
# Link with PJSUA library
# Result: ./obd binary (~8-12 MB)
```

**For baseline testing (original capacity, 4 workers × 2500 calls):**
```bash
make clean
make tune

# Uses defaults: 4 workers, 2500 calls per worker = 10K total capacity
```

### Step 5: Verify Compilation Flags
```bash
# Check that PJSUA limits were compiled correctly
strings ./obd | grep -i pjsua_max_acc

# Check ring buffer and queue sizes are defined
strings ./obd | grep -i "ring\|queue"

# Preferred: use readelf if available
readelf -s ./obd | grep -E "PJSUA|ring|queue"
```

### Step 6: Staging Test (5K TPS)

**Start dispatcher:**
```bash
./obd --config test.conf  # or with command-line args
# Expected logs:
# - "udp_recv_threads_created count=4"
# - "parser_threads_created count=8"
# - "worker_queues_init"
# - "ring_buffer_init"
# - "pjsip_compile_limits PJSUA_MAX_ACC=10000"
```

**Send test traffic (5K TPS for 60 seconds):**
```bash
./send_udp_tps.sh 5000 60

# Expected:
# SUCCESS: 99%+
# FAILED: <1%
# NOT_REACHABLE: <1%
# Dispatcher CPU: <30%
```

### Step 7: Full Load Test (10K TPS)

```bash
./send_udp_tps.sh 10000 60

# Expected:
# SUCCESS: 95%+ (some backpressure NACKs OK)
# FAILED: <3%
# NOT_REACHABLE: <3%
# Dispatcher CPU: <50%
# Worker CPU: 15-20% each
```

### Step 8: Sustained Load Test (10K TPS for 5 minutes)

```bash
./send_udp_tps.sh 10000 300

# Watch for:
# - Memory usage stable (no leaks)
# - Queue depths stable
# - No "ring_buffer_full" or "worker_queue_full" logs
# - CPU usage consistent
```

---

## WHAT EACH FIX DOES

### FIX #1: Ring Buffer + Parser Threads (dispatcher.c)

**Before:**
```c
while (g_running) {
    recvfrom(sock, buf, ...);     // recv
    json_get(buf, ...);            // ← BLOCKING - 50-100µs per request
    json_get(buf, ...);
    json_get(buf, ...);
    json_get(buf, ...);
    dedup_check_and_set(...);      // ← BLOCKING - spinlock
    select_worker(...);            // ← BLOCKING - 100 iterations
    send(worker_sock, ...);        // ← BLOCKING - kernel syscall
}
```

At 10K TPS: Single thread @ 100% CPU, kernel drops packets

**After:**
```
[UDP Recv Thread 1-4] (SO_REUSEPORT)
    ↓ (just memcpy + atomic)
[Ring Buffer 4K slots]
    ↓
[Parser Thread 1-8]
    ├─ JSON parse
    ├─ dedup check
    ├─ worker selection
    └─ routing (queue push)
```

At 10K TPS: Dispatcher CPU ~15-20%, no drops

**Key improvements:**
- Recv threads: ~100% CPU (minimal work, just copy)
- Parser threads: ~20% each (distributed load)
- Total throughput: 10K+ TPS sustained

---

### FIX #2: Worker Queue + Backpressure (dispatcher.c, worker.c)

**Before:**
```c
ssize_t sent = send(g_worker_socks[w], &req, sizeof(req), MSG_DONTWAIT);
if (sent > 0) {
    // Request sent
} else {
    // REQUEST SILENTLY DROPPED - no feedback to client
    LOG("route_failed", ...);
}
```

**After:**
```c
if (worker_queue_push(w, &req) == 0) {
    // Request queued successfully
    LOG("queued", ...);
} else {
    // Queue full - explicit backpressure
    LOG("worker_queue_full", ...);
    // Fallback to direct Unix socket send
    // Or send NACK response to client (optional)
}
```

**Key improvements:**
- 8K per-worker queue (reduces loss at worker buffer boundary)
- Explicit feedback when system is full
- Optional: Send NACK JSON response to upstream client
- Worker can drain queue at own pace

---

### FIX #3: PJSUA_MAX_ACC Compile-Time Limit (sip_engine.c, Makefile)

**Before:**
```c
// Compiled with default: PJSUA_MAX_ACC = 32
// Result: After 32 concurrent calls, all pjsua_acc_add() fail
```

**After:**
```c
// In sip_engine.c:
#ifndef PJSUA_MAX_ACC
#define PJSUA_MAX_ACC 10000  // FIX #3
#endif

// In Makefile:
CFLAGS_LIMITS = \
    -DPJSUA_MAX_ACC=10000 \
    -DPJSUA_MAX_CALLS=100 \
    -DPJ_IOQUEUE_MAX_HANDLERS=10000
```

**Key improvements:**
- Accounts no longer hit global limit at 32
- Supports 100 workers × 100 concurrent calls = 10K accounts
- Diagnostic logging shows actual limits at startup
- Warning if limits are still insufficient

---

## LOGGING CHANGES

### New Logs in dispatcher.c (FIX #1 & #2)

```json
{"w":"dispatcher","ev":"ring_buffer_init","size":4096}
{"w":"dispatcher","ev":"worker_queues_init","workers":100,"queue_size":8192}
{"w":"dispatcher","ev":"udp_recv_threads_created","count":4}
{"w":"dispatcher","ev":"parser_threads_created","count":8}
{"w":"dispatcher","ev":"udp_recv_thread_started"}
{"w":"dispatcher","ev":"parser_thread_started","parser_id":0}
{"w":"dispatcher","ev":"ring_buffer_full","drops":15,"total_received":50000}
{"w":"dispatcher","ev":"worker_queue_full","worker":3,"queue_size":8192}
{"w":"dispatcher","ev":"worker_queue_metrics","worker":0,"pushed":1000,"popped":950,"drops":0}
```

### New Logs in sip_engine.c (FIX #3)

```json
{"w":"w0","ev":"pjsip_compile_limits","PJSUA_MAX_CALLS":100,"PJSUA_MAX_ACC":10000,"PJ_IOQUEUE_MAX_HANDLERS":10000}
{"w":"w0","ev":"critical_pjsua_account_limit","compiled":10000,"required":10000,"status":"SUFFICIENT"}
```

---

## PERFORMANCE EXPECTATIONS

| Metric | Before | After |
|--------|--------|-------|
| Max Throughput | 2-3K TPS | 10K+ TPS |
| Dispatcher CPU @ 10K | 100% | 15-20% |
| Silent Packet Loss | 70% | 0% (explicit backpressure) |
| Worker Queue Depth | N/A | <1000 (typical) |
| Ring Buffer Utilization | N/A | <10% (typical) |
| Memory per Worker | ~20MB | ~20MB (unchanged) |
| Dispatcher Memory | ~50MB | ~150MB (ring + queues) |

---

## TROUBLESHOOTING

### Build Fails: "undefined reference to pjsua_..."
**Cause:** PJSIP library not found
**Fix:** 
```bash
pkg-config --cflags --libs libpjproject
# Ensure output shows /usr/include/pjproject paths
# Update Makefile PJSIP_CFLAGS and PJSIP_LIBS if needed
```

### Compilation Warning: "PJSUA_MAX_ACC might be insufficient"
**Cause:** Compiled limit < (workers × calls)
**Fix:**
```bash
# Verify Makefile has:
CFLAGS_LIMITS = -DPJSUA_MAX_ACC=10000
# And compile: make tune OBD_NUM_WORKERS=100 OBD_CALLS_PER_WORKER=100
```

### Runtime: "pjsua_acc_add failed" (503 errors spike)
**Cause:** PJSUA_MAX_ACC still at old limit
**Fix:**
```bash
# Check actual compiled limit:
strings ./obd | grep PJSUA_MAX_ACC
# Should show 10000, not 32

# Rebuild with explicit flags:
make clean
CFLAGS="-DPJSUA_MAX_ACC=10000" make tune
```

### Runtime: "ring_buffer_full" logs
**Cause:** Ring buffer size too small for traffic pattern
**Fix:**
```c
// In dispatcher.c, increase:
#define DISPATCHER_RING_SIZE 16384  // was 4096
// Rebuild and test
```

### Runtime: "worker_queue_full" logs
**Cause:** Worker can't keep up (PJSIP bottleneck or network latency)
**Fix:**
```bash
# Check worker CPU usage and active call count per worker
# If asymmetric, improve worker selection (currently: least-loaded)
# Consider: increase OBD_REPORT_THREADS (default: 4)
# Consider: spread calls more evenly across workers
```

---

## ROLLBACK PROCEDURE

If performance degradation or instability is observed:

```bash
# Stop dispatcher
pkill obd

# Restore from backup
cp backups/v2.1.0/dispatcher.c .
cp backups/v2.1.0/worker.c .
cp backups/v2.1.0/sip_engine.c .
cp backups/v2.1.0/Makefile .

# Rebuild old version
make clean
make

# Restart
./obd --config test.conf &
```

---

## PRODUCTION DEPLOYMENT CHECKLIST

- [ ] Backup current code (Step 1)
- [ ] Replace files (Step 2)
- [ ] Verify file structure (Step 3)
- [ ] Build for target configuration (Step 4)
- [ ] Verify compilation flags (Step 5)
- [ ] Staging test at 5K TPS (Step 6)
- [ ] Full load test at 10K TPS (Step 7)
- [ ] Sustained test for 5+ minutes (Step 8)
- [ ] Monitor logs for "critical_" or "failed" messages
- [ ] Document baseline metrics before production
- [ ] Schedule deployment during maintenance window
- [ ] Have rollback plan ready
- [ ] Monitor first 24 hours for memory leaks

---

## NEXT STEPS (OPTIONAL OPTIMIZATIONS)

1. **Binary Protocol** (30% faster parsing): Replace JSON with binary format
2. **Account Pooling**: Pre-allocate accounts at startup, reuse
3. **Smarter Worker Selection**: Use exponential smoothing instead of instant load
4. **Enhanced Backpressure**: Return HTTP 503 with Retry-After header
5. **Metrics Export**: Push metrics to Prometheus or OpenTelemetry

---

**Questions?** Refer to:
- **OBD_QUICK_REFERENCE.md** - Architecture overview
- **OBD_PERFORMANCE_ANALYSIS.md** - Detailed bottleneck analysis
- **OBD_CODE_CHECKLIST.md** - Specific code changes
