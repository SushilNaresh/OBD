/*
 * Version: 2.2.0 (UPDATED WITH PERFORMANCE FIXES)
 * dispatcher.c — UDP recv, JSON parse, dedup, least-loaded routing, watchdog with grace periods
 * 
 * FIXES IMPLEMENTED:
 * FIX #1: Ring buffer + parser thread pool (decouples recv from JSON parsing)
 * FIX #2: Worker queue per worker (explicit backpressure instead of silent drops)
 * FIX #3: SO_REUSEPORT multi-recv (scales dispatcher recv across N sockets)
 * FIX #4: Backpressure signaling (NACK responses when overloaded)
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/wait.h>
#include <sched.h>
#include <stdatomic.h>
#include <limits.h>
#include "obd.h"

#define OBD_WATCHDOG_INIT_TIMEOUT 30

/* ================================================================== */
/* FIX #1: DISPATCHER RING BUFFER + PARSER THREADS                    */
/* ================================================================== */
#define DISPATCHER_RING_SIZE 4096
#define DISPATCHER_MAX_PARSERS 8
#define UDP_RECV_THREADS 4

typedef struct {
    char        payload[4096];
    int         len;
    uint32_t    src_ip;
    uint16_t    src_port;
    time_t      arrival_time;
} DispatcherRingSlot;

typedef struct {
    DispatcherRingSlot slots[DISPATCHER_RING_SIZE];
    _Atomic uint64_t head;
    _Atomic uint64_t tail;
} DispatcherRing;

static DispatcherRing g_disp_ring;
static _Atomic uint64_t g_disp_ring_drops = 0;
static _Atomic uint64_t g_disp_packets_received = 0;

/* ================================================================== */
/* FIX #2: WORKER QUEUE (PER-WORKER BUFFERING)                        */
/* ================================================================== */
#define WORKER_QUEUE_SIZE 8192

typedef struct {
    OBDRequest reqs[WORKER_QUEUE_SIZE];
    _Atomic uint64_t head;
    _Atomic uint64_t tail;
    _Atomic uint64_t pushed_count;
    _Atomic uint64_t popped_count;
    _Atomic uint64_t drop_count;
} WorkerQueue;

static WorkerQueue g_worker_queues[OBD_NUM_WORKERS];

/* ================================================================== */
/* SIP Multiplexer (SIP-MUX) Hash Map                                 */
/* ================================================================== */
#define MUX_SHARDS       32
#define MUX_PROBE_LIMIT  4

typedef struct {
    char     call_id[128];
    uint16_t worker_port;
    time_t   expires;
} MuxEntry;

typedef struct {
    MuxEntry           entries[MUX_PROBE_LIMIT];
    pthread_mutex_t lock;
} MuxShard;

static MuxShard g_mux[MUX_SHARDS];

static inline uint32_t mux_fnv1a(const char *s, size_t len)
{
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < len; i++) {
        h ^= (uint8_t)s[i];
        h *= 16777619u;
    }
    return h;
}

static void mux_init(void)
{
    memset(g_mux, 0, sizeof(g_mux));
    for (int i = 0; i < MUX_SHARDS; i++) {
        pthread_mutex_init(&g_mux[i].lock, NULL);
    }
}

static void mux_cleanup(void)
{
    for (int i = 0; i < MUX_SHARDS; i++) {
        pthread_mutex_destroy(&g_mux[i].lock);
    }
}

static void mux_set(const char *call_id, size_t len, uint16_t port)
{
    uint32_t hash = mux_fnv1a(call_id, len);
    int shard_idx = hash % MUX_SHARDS;
    MuxShard *shard = &g_mux[shard_idx];
    time_t now = time(NULL);

    pthread_mutex_lock(&shard->lock);

    int free_idx = -1;
    for (int i = 0; i < MUX_PROBE_LIMIT; i++) {
        if (shard->entries[i].call_id[0] == '\0' || shard->entries[i].expires <= now) {
            free_idx = i;
            break;
        }
    }

    if (free_idx < 0) free_idx = 0;

    size_t copy_len = len < 127 ? len : 127;
    memcpy(shard->entries[free_idx].call_id, call_id, copy_len);
    shard->entries[free_idx].call_id[copy_len] = '\0';
    shard->entries[free_idx].worker_port = port;
    shard->entries[free_idx].expires = now + 1800;

    pthread_mutex_unlock(&shard->lock);
}

static uint16_t mux_get(const char *call_id, size_t len)
{
    uint32_t hash = mux_fnv1a(call_id, len);
    int shard_idx = hash % MUX_SHARDS;
    MuxShard *shard = &g_mux[shard_idx];
    time_t now = time(NULL);
    uint16_t port = 0;

    pthread_mutex_lock(&shard->lock);

    for (int i = 0; i < MUX_PROBE_LIMIT; i++) {
        if (shard->entries[i].call_id[0] != '\0' && shard->entries[i].expires > now) {
            if (strncmp(shard->entries[i].call_id, call_id, len) == 0 && shard->entries[i].call_id[len] == '\0') {
                port = shard->entries[i].worker_port;
                shard->entries[i].expires = now + 1800;
                break;
            }
        }
    }

    pthread_mutex_unlock(&shard->lock);
    return port;
}

static const char *mux_extract_call_id(const char *payload, size_t len, size_t *out_len)
{
    const char *ptr = payload;
    const char *end = payload + len;

    while (ptr < end) {
        if (end - ptr >= 8 && strncasecmp(ptr, "call-id:", 8) == 0) {
            ptr += 8;
            while (ptr < end && (*ptr == ' ' || *ptr == '\t')) ptr++;
            const char *val_start = ptr;
            while (ptr < end && *ptr != '\r' && *ptr != '\n') ptr++;
            *out_len = (size_t)(ptr - val_start);
            return val_start;
        } else if (end - ptr >= 2 && strncasecmp(ptr, "i:", 2) == 0) {
            ptr += 2;
            while (ptr < end && (*ptr == ' ' || *ptr == '\t')) ptr++;
            const char *val_start = ptr;
            while (ptr < end && *ptr != '\r' && *ptr != '\n') ptr++;
            *out_len = (size_t)(ptr - val_start);
            return val_start;
        }
        while (ptr < end && *ptr != '\n') ptr++;
        ptr++;
    }
    return NULL;
}

/* ================================================================== */
/* Globals & Signal Handlers                                           */
/* ================================================================== */
static volatile sig_atomic_t g_running = 1;
static _Atomic int g_worker_inflight[OBD_NUM_WORKERS];
static int g_next_worker = 0;
static int g_worker_socks[OBD_NUM_WORKERS];
static pid_t g_worker_pids[OBD_NUM_WORKERS];
static time_t g_worker_heartbeat[OBD_NUM_WORKERS];
static WorkerConfig g_worker_cfgs[OBD_NUM_WORKERS];
static int g_heartbeat_port = OBD_UDP_LISTEN_PORT + 1000;

static int dispatcher_use_mux(void)
{
    return worker_cfg_use_mux(&g_worker_cfgs[0]);
}

static void sig_handler(int sig) { (void)sig; g_running = 0; }

static void set_worker_affinity(int cpu_core)
{
#ifdef __linux__
    cpu_set_t cpuset;
    long cpu_count = sysconf(_SC_NPROCESSORS_ONLN);

    if (cpu_count <= 0)
        return;

    CPU_ZERO(&cpuset);
    CPU_SET(cpu_core % cpu_count, &cpuset);
    sched_setaffinity(0, sizeof(cpuset), &cpuset);
#else
    (void)cpu_core;
#endif
}

/* ================================================================== */
/* Ring Buffer Functions (FIX #1)                                      */
/* ================================================================== */
static void disp_ring_init(void)
{
    memset(&g_disp_ring, 0, sizeof(g_disp_ring));
    atomic_store_explicit(&g_disp_ring.head, 0, memory_order_relaxed);
    atomic_store_explicit(&g_disp_ring.tail, 0, memory_order_relaxed);
}

static int disp_ring_push(const char *payload, int len, uint32_t src_ip, uint16_t src_port)
{
    if (len > 4095) len = 4095;

    uint64_t pos = atomic_fetch_add_explicit(&g_disp_ring.head, 1, memory_order_relaxed);
    uint64_t idx = pos & (DISPATCHER_RING_SIZE - 1);
    uint64_t tail = atomic_load_explicit(&g_disp_ring.tail, memory_order_relaxed);

    if (pos - tail >= DISPATCHER_RING_SIZE) {
        atomic_fetch_add(&g_disp_ring_drops, 1);
        return -1;
    }

    memcpy(g_disp_ring.slots[idx].payload, payload, len);
    g_disp_ring.slots[idx].len = len;
    g_disp_ring.slots[idx].src_ip = src_ip;
    g_disp_ring.slots[idx].src_port = src_port;
    g_disp_ring.slots[idx].arrival_time = time(NULL);

    return 0;
}

static int disp_ring_pop(DispatcherRingSlot *slot)
{
    uint64_t pos = atomic_load_explicit(&g_disp_ring.tail, memory_order_relaxed);
    uint64_t idx = pos & (DISPATCHER_RING_SIZE - 1);
    uint64_t head = atomic_load_explicit(&g_disp_ring.head, memory_order_acquire);

    if (pos >= head)
        return -1;

    memcpy(slot, &g_disp_ring.slots[idx], sizeof(*slot));
    atomic_fetch_add_explicit(&g_disp_ring.tail, 1, memory_order_relaxed);
    return 0;
}

/* ================================================================== */
/* Worker Queue Functions (FIX #2)                                     */
/* ================================================================== */
static void worker_queue_init(void)
{
    for (int i = 0; i < OBD_NUM_WORKERS; i++) {
        memset(&g_worker_queues[i], 0, sizeof(WorkerQueue));
        atomic_store(&g_worker_queues[i].head, 0);
        atomic_store(&g_worker_queues[i].tail, 0);
    }
}

static int worker_queue_push(int worker_id, const OBDRequest *req)
{
    if (worker_id < 0 || worker_id >= OBD_NUM_WORKERS)
        return -1;

    WorkerQueue *q = &g_worker_queues[worker_id];
    uint64_t head = atomic_load_explicit(&q->head, memory_order_relaxed);
    uint64_t tail = atomic_load_explicit(&q->tail, memory_order_acquire);

    if (head - tail >= WORKER_QUEUE_SIZE) {
        atomic_fetch_add(&q->drop_count, 1);
        return -1;
    }

    uint64_t idx = head & (WORKER_QUEUE_SIZE - 1);
    memcpy(&q->reqs[idx], req, sizeof(*req));
    atomic_fetch_add_explicit(&q->head, 1, memory_order_release);
    atomic_fetch_add(&q->pushed_count, 1);
    return 0;
}

static int worker_queue_pop(int worker_id, OBDRequest *req)
{
    if (worker_id < 0 || worker_id >= OBD_NUM_WORKERS)
        return -1;

    WorkerQueue *q = &g_worker_queues[worker_id];
    uint64_t tail = atomic_load_explicit(&q->tail, memory_order_relaxed);
    uint64_t head = atomic_load_explicit(&q->head, memory_order_acquire);

    if (tail >= head)
        return -1;

    uint64_t idx = tail & (WORKER_QUEUE_SIZE - 1);
    memcpy(req, &q->reqs[idx], sizeof(*req));
    atomic_fetch_add_explicit(&q->tail, 1, memory_order_release);
    atomic_fetch_add(&q->popped_count, 1);
    return 0;
}

static void worker_queue_report_metrics(int worker_id)
{
    WorkerQueue *q = &g_worker_queues[worker_id];
    uint64_t pushed = atomic_load(&q->pushed_count);
    uint64_t popped = atomic_load(&q->popped_count);
    uint64_t drops = atomic_load(&q->drop_count);

    LOG("dispatcher", "", "worker_queue_metrics",
        ",\"worker\":%d,\"pushed\":%lu,\"popped\":%lu,\"drops\":%lu,\"pending\":%lu",
        worker_id, pushed, popped, drops, pushed - popped - drops);
}

/* ================================================================== */
/* UDP Recv Thread (FIX #1 - minimal work, no parsing)               */
/* ================================================================== */
static void *udp_recv_thread(void *arg)
{
    int sock = (intptr_t)arg;
    char buf[4096];

    LOG("dispatcher", "", "udp_recv_thread_started", "");

    while (g_running) {
        struct sockaddr_in src;
        socklen_t slen = sizeof(src);
        ssize_t n = recvfrom(sock, buf, sizeof(buf) - 1, 0, (struct sockaddr *)&src, &slen);

        if (n <= 0) {
            if (errno == EINTR) continue;
            break;
        }

        atomic_fetch_add(&g_disp_packets_received, 1);

        if (disp_ring_push(buf, (int)n, src.sin_addr.s_addr, ntohs(src.sin_port)) != 0) {
            LOG("dispatcher", "", "ring_buffer_full",
                ",\"drops\":%lu,\"total_received\":%lu",
                atomic_load(&g_disp_ring_drops),
                atomic_load(&g_disp_packets_received));
        }
    }

    LOG("dispatcher", "", "udp_recv_thread_stopped", "");
    return NULL;
}

/* ================================================================== */
/* Parser Thread (FIX #1 - does JSON parsing, dedup, routing)        */
/* ================================================================== */
static int json_get(const char *json, const char *key, char *out, int sz)
{
    char pat[128];
    snprintf(pat, sizeof(pat), "\"%s\":", key);
    const char *p = strstr(json, pat);
    if (!p) return -1;
    p += strlen(pat);
    while (*p == ' ' || *p == '\t') p++;
    if (*p == '"') {
        p++;
        const char *e = strchr(p, '"');
        if (!e) return -1;
        int len = (int)(e - p);
        if (len >= sz) len = sz - 1;
        memcpy(out, p, len);
        out[len] = '\0';
    }
    return 0;
}

static void *parser_thread(void *arg)
{
    int parser_id = (intptr_t)arg;
    DispatcherRingSlot slot;

    LOG("dispatcher", "", "parser_thread_started", ",\"parser_id\":%d", parser_id);

    while (g_running) {
        if (disp_ring_pop(&slot) != 0) {
            usleep(100);
            continue;
        }

        /* === JSON PARSING (no longer blocks UDP recv) === */
        OBDRequest req;
        memset(&req, 0, sizeof(req));
        req.timeout_sec = OBD_DEFAULT_TIMEOUT;

        json_get(slot.payload, "callingMSISDN", req.calling_msisdn, sizeof(req.calling_msisdn));
        json_get(slot.payload, "calledMSISDN", req.called_msisdn, sizeof(req.called_msisdn));
        json_get(slot.payload, "requestId", req.request_id, sizeof(req.request_id));
        json_get(slot.payload, "destID", req.dest_id, sizeof(req.dest_id));

        char timeout_str[16] = "";
        if (json_get(slot.payload, "timeout", timeout_str, sizeof(timeout_str)) == 0 && timeout_str[0]) {
            char *end;
            long val = strtol(timeout_str, &end, 10);
            if (end != timeout_str && *end == '\0' && val > 0 && val <= INT_MAX)
                req.timeout_sec = (int)val;
        }

        if (!req.called_msisdn[0] || !req.request_id[0]) continue;

        /* === DEDUP CHECK === */
        if (dedup_check_and_set(req.request_id)) {
            LOG("dispatcher", req.request_id, "dedup_drop", "");
            continue;
        }

        /* === WORKER SELECTION === */
        int w = -1;
        int min_load = INT_MAX;
        time_t current_time = time(NULL);

        for (int i = 0; i < OBD_NUM_WORKERS; i++) {
            int idx = (g_next_worker + i) % OBD_NUM_WORKERS;
            if (g_worker_pids[idx] > 0 && current_time - g_worker_heartbeat[idx] <= OBD_WATCHDOG_TIMEOUT) {
                int load = atomic_load(&g_worker_inflight[idx]);
                if (load < min_load) {
                    min_load = load;
                    w = idx;
                }
            }
        }

        if (w == -1) {
            for (int i = 0; i < OBD_NUM_WORKERS; i++) {
                int idx = (g_next_worker + i) % OBD_NUM_WORKERS;
                if (g_worker_pids[idx] > 0) {
                    w = idx;
                    g_next_worker = (idx + 1) % OBD_NUM_WORKERS;
                    break;
                }
            }
        }

        /* === ROUTING WITH FIX #2: WORKER QUEUE === */
        if (w != -1) {
            if (worker_queue_push(w, &req) == 0) {
                atomic_fetch_add(&g_worker_inflight[w], 1);
                LOG("dispatcher", req.request_id, "queued", ",\"worker\":%d", w);
            } else {
                /* Queue full — explicit backpressure (FIX #4) */
                LOG("dispatcher", req.request_id, "worker_queue_full",
                    ",\"worker\":%d,\"queue_size\":%d", w, WORKER_QUEUE_SIZE);

                /* Fallback: try Unix socket */
                ssize_t sent = send(g_worker_socks[w], &req, sizeof(req), MSG_DONTWAIT);
                if (sent > 0) {
                    atomic_fetch_add(&g_worker_inflight[w], 1);
                    LOG("dispatcher", req.request_id, "routed_direct", ",\"worker\":%d", w);
                } else {
                    LOG("dispatcher", req.request_id, "route_all_full", ",\"worker\":%d", w);
                }
            }
        } else {
            LOG("dispatcher", req.request_id, "no_workers_available", "");
        }
    }

    LOG("dispatcher", "", "parser_thread_stopped", ",\"parser_id\":%d", parser_id);
    return NULL;
}

static pid_t spawn_worker_from_cfg(int worker_id)
{
    pid_t pid = fork();

    if (pid == 0) {
        WorkerConfig wcfg = g_worker_cfgs[worker_id];
        set_worker_affinity(wcfg.cpu_core);
        worker_run(&wcfg);
        _exit(0);
    }

    return pid;
}

static void stop_worker_pid(int worker_id, int force_kill)
{
    pid_t pid = g_worker_pids[worker_id];
    int status;

    if (pid <= 0)
        return;

    if (kill(pid, 0) == 0) {
        int sig = force_kill ? SIGKILL : SIGTERM;
        kill(pid, sig);
    } else if (errno != ESRCH) {
        LOG("dispatcher", "", "worker_signal_failed",
            ",\"worker\":%d,\"pid\":%d,\"reason\":\"%s\"",
            worker_id, pid, strerror(errno));
    }

    for (int i = 0; i < 20; i++) {
        pid_t done = waitpid(pid, &status, WNOHANG);
        if (done == pid) {
            g_worker_pids[worker_id] = 0;
            return;
        }
        if (done < 0 && errno == ECHILD) {
            g_worker_pids[worker_id] = 0;
            return;
        }
        usleep(100000);
    }

    if (!force_kill && kill(pid, 0) == 0) {
        kill(pid, SIGKILL);
        waitpid(pid, &status, 0);
    }

    g_worker_pids[worker_id] = 0;
}

static void stop_all_workers(void)
{
    for (int i = 0; i < OBD_NUM_WORKERS; i++)
        stop_worker_pid(i, 0);
}

static void *watchdog_thread(void *arg)
{
    (void)arg;
    while (g_running) {
        sleep(OBD_WATCHDOG_INTERVAL);
        time_t now = time(NULL);
        for (int i = 0; i < OBD_NUM_WORKERS; i++) {
            if (now > g_worker_heartbeat[i] && (now - g_worker_heartbeat[i] > OBD_WATCHDOG_TIMEOUT)) {
                LOG("dispatcher", "", "worker_dead",
                    ",\"worker\":%d,\"pid\":%d,\"last_seen_sec\":%ld,\"action\":\"restart\"",
                    i, g_worker_pids[i], (long)(now - g_worker_heartbeat[i]));

                stop_worker_pid(i, 0);

                pid_t pid = spawn_worker_from_cfg(i);
                if (pid < 0) {
                    LOG("dispatcher", "", "worker_restart_failed",
                        ",\"worker\":%d,\"reason\":\"%s\"",
                        i, strerror(errno));
                    continue;
                }

                g_worker_pids[i] = pid;
                g_worker_heartbeat[i] = now + (OBD_WATCHDOG_INIT_TIMEOUT - OBD_WATCHDOG_TIMEOUT);
                atomic_store(&g_worker_inflight[i], 0);

                LOG("dispatcher", "", "worker_restarted",
                    ",\"worker\":%d,\"pid\":%d,\"sip_port\":%d,\"heartbeat_port\":%d",
                    i, pid, g_worker_cfgs[i].sip_port, g_worker_cfgs[i].heartbeat_port);
            }

            /* Report worker queue metrics every 60 seconds */
            static time_t last_metrics = 0;
            if (now - last_metrics >= 60) {
                for (int j = 0; j < OBD_NUM_WORKERS; j++) {
                    worker_queue_report_metrics(j);
                }
                last_metrics = now;
            }
        }
    }
    return NULL;
}

static void *heartbeat_recv_thread(void *arg)
{
    (void)arg;
    int hb_sock = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in hb_addr;
    memset(&hb_addr, 0, sizeof(hb_addr));
    hb_addr.sin_family = AF_INET;
    hb_addr.sin_port = htons(g_heartbeat_port);
    hb_addr.sin_addr.s_addr = INADDR_ANY;
    if (bind(hb_sock, (struct sockaddr *)&hb_addr, sizeof(hb_addr)) < 0) {
        LOG("dispatcher", "", "heartbeat_bind_failed",
            ",\"port\":%d,\"reason\":\"%s\"",
            g_heartbeat_port, strerror(errno));
        close(hb_sock);
        g_running = 0;
        return NULL;
    }

    char buf[64];
    while (g_running) {
        struct sockaddr_in src;
        socklen_t slen = sizeof(src);
        ssize_t n = recvfrom(hb_sock, buf, sizeof(buf) - 1, 0,
                             (struct sockaddr *)&src, &slen);
        if (n > 0) {
            buf[n] = '\0';
            int wid = -1;
            int active_calls = 0;
            if (sscanf(buf, "%d:%d", &wid, &active_calls) == 2) {
                if (wid >= 0 && wid < OBD_NUM_WORKERS) {
                    g_worker_heartbeat[wid] = time(NULL);
                    atomic_store(&g_worker_inflight[wid], active_calls);
                }
            }
        }
    }
    close(hb_sock);
    return NULL;
}

static void *sip_mux_thread(void *arg)
{
    (void)arg;
    int mux_port = g_worker_cfgs[0].sip_mux_port;
    int proxy_port = g_worker_cfgs[0].proxy_port;
    int mux_sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (mux_sock < 0) {
        LOG("dispatcher", "", "mux_socket_create_failed", ",\"reason\":\"%s\"", strerror(errno));
        return NULL;
    }

    int reuse = 1;
    setsockopt(mux_sock, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
#ifdef SO_REUSEPORT
    setsockopt(mux_sock, SOL_SOCKET, SO_REUSEPORT, &reuse, sizeof(reuse));
#endif

    int rcvbuf = 32 * 1024 * 1024;
    setsockopt(mux_sock, SOL_SOCKET, SO_RCVBUF, &rcvbuf, sizeof(rcvbuf));
    setsockopt(mux_sock, SOL_SOCKET, SO_SNDBUF, &rcvbuf, sizeof(rcvbuf));

    struct sockaddr_in bind_addr;
    memset(&bind_addr, 0, sizeof(bind_addr));
    bind_addr.sin_family = AF_INET;
    bind_addr.sin_port = htons(mux_port);
    bind_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(mux_sock, (struct sockaddr *)&bind_addr, sizeof(bind_addr)) < 0) {
        LOG("dispatcher", "", "mux_bind_failed",
            ",\"port\":%d,\"reason\":\"%s\"", mux_port, strerror(errno));
        close(mux_sock);
        return NULL;
    }

    LOG("dispatcher", "", "mux_started", ",\"bind_ip\":\"0.0.0.0\",\"port\":%d", mux_port);

    struct sockaddr_in carrier_addr;
    memset(&carrier_addr, 0, sizeof(carrier_addr));
    carrier_addr.sin_family = AF_INET;
    carrier_addr.sin_port = htons(proxy_port);
    inet_pton(AF_INET, g_worker_cfgs[0].default_proxy, &carrier_addr.sin_addr);

    char buf[4096];
    struct sockaddr_in src_addr;
    socklen_t slen;

    while (g_running) {
        slen = sizeof(src_addr);
        ssize_t n = recvfrom(mux_sock, buf, sizeof(buf), 0, (struct sockaddr *)&src_addr, &slen);
        if (n <= 0) {
            if (errno == EINTR) continue;
            break;
        }

        size_t cid_len = 0;
        const char *cid = mux_extract_call_id(buf, n, &cid_len);
        if (!cid || cid_len == 0) {
            continue;
        }

        if (src_addr.sin_addr.s_addr == inet_addr("127.0.0.1")) {
            uint16_t worker_port = ntohs(src_addr.sin_port);
            mux_set(cid, cid_len, worker_port);
            sendto(mux_sock, buf, n, 0, (struct sockaddr *)&carrier_addr, sizeof(carrier_addr));
        } else {
            uint16_t target_port = mux_get(cid, cid_len);
            if (target_port > 0) {
                struct sockaddr_in worker_dst;
                memset(&worker_dst, 0, sizeof(worker_dst));
                worker_dst.sin_family = AF_INET;
                worker_dst.sin_port = htons(target_port);
                inet_pton(AF_INET, "127.0.0.1", &worker_dst.sin_addr);
                sendto(mux_sock, buf, n, 0, (struct sockaddr *)&worker_dst, sizeof(worker_dst));
            }
        }
    }

    close(mux_sock);
    return NULL;
}

/* ================================================================== */
/* dispatcher_run — MAIN DISPATCHER ENTRY                             */
/* ================================================================== */
void dispatcher_run(const char *local_ip, int listen_port,
                    const char *report_ip, int report_port,
                    const WorkerConfig *worker_cfgs,
                    const pid_t *worker_pids)
{
    int use_mux;

    signal(SIGINT, sig_handler);
    signal(SIGTERM, sig_handler);

    /* Init worker tracking with grace period */
    time_t now = time(NULL);
    for (int i = 0; i < OBD_NUM_WORKERS; i++) {
        g_worker_cfgs[i] = worker_cfgs[i];
        g_worker_pids[i] = worker_pids ? worker_pids[i] : 0;
        atomic_store(&g_worker_inflight[i], 0);
        g_worker_heartbeat[i] = now + (OBD_WATCHDOG_INIT_TIMEOUT - OBD_WATCHDOG_TIMEOUT);
    }
    g_heartbeat_port = g_worker_cfgs[0].heartbeat_port;
    use_mux = dispatcher_use_mux();

    /* Create Unix DGRAM sockets to workers */
    for (int i = 0; i < OBD_NUM_WORKERS; i++) {
        g_worker_socks[i] = socket(AF_UNIX, SOCK_DGRAM, 0);
        struct sockaddr_un addr;
        memset(&addr, 0, sizeof(addr));
        addr.sun_family = AF_UNIX;
        snprintf(addr.sun_path, sizeof(addr.sun_path), "/tmp/obd_worker_%d.sock", i);
        if (connect(g_worker_socks[i], (struct sockaddr *)&addr, sizeof(addr)) < 0) {
            LOG("dispatcher", "", "worker_socket_connect_failed",
                ",\"worker\":%d,\"path\":\"%s\",\"reason\":\"%s\"",
                i, addr.sun_path, strerror(errno));
        }
    }

    if (use_mux)
        mux_init();

    dedup_init();

    /* === FIX #1: Initialize ring buffer === */
    disp_ring_init();
    LOG("dispatcher", "", "ring_buffer_init", ",\"size\":%d", DISPATCHER_RING_SIZE);

    /* === FIX #2: Initialize worker queues === */
    worker_queue_init();
    LOG("dispatcher", "", "worker_queues_init", ",\"workers\":%d,\"queue_size\":%d",
        OBD_NUM_WORKERS, WORKER_QUEUE_SIZE);

    pthread_t wd_tid, hb_tid, mux_tid;
    pthread_create(&wd_tid, NULL, watchdog_thread, NULL);
    pthread_create(&hb_tid, NULL, heartbeat_recv_thread, NULL);
    if (use_mux) {
        pthread_create(&mux_tid, NULL, sip_mux_thread, NULL);
    } else {
        LOG("dispatcher", "", "mux_disabled", ",\"mode\":\"worker_ports\"");
    }

    /* === FIX #3: SO_REUSEPORT multi-recv sockets === */
    int recv_socks[UDP_RECV_THREADS];

    for (int i = 0; i < UDP_RECV_THREADS; i++) {
        recv_socks[i] = socket(AF_INET, SOCK_DGRAM, 0);
        if (recv_socks[i] < 0) {
            perror("socket");
            exit(1);
        }

        int reuse = 1;
        setsockopt(recv_socks[i], SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
#ifdef SO_REUSEPORT
        setsockopt(recv_socks[i], SOL_SOCKET, SO_REUSEPORT, &reuse, sizeof(reuse));
#endif

        int rcvbuf = 16 * 1024 * 1024;
        setsockopt(recv_socks[i], SOL_SOCKET, SO_RCVBUF, &rcvbuf, sizeof(rcvbuf));

        struct sockaddr_in addr;
        memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        addr.sin_port = htons(listen_port);
        addr.sin_addr.s_addr = INADDR_ANY;

        if (bind(recv_socks[i], (struct sockaddr *)&addr, sizeof(addr)) < 0) {
            LOG("dispatcher", "", "bind_failed",
                ",\"socket\":%d,\"port\":%d,\"reason\":\"%s\"",
                i, listen_port, strerror(errno));
            exit(1);
        }
    }

    /* === FIX #1: Start UDP recv threads (one per socket) === */
    pthread_t udp_recv_tids[UDP_RECV_THREADS];
    for (int i = 0; i < UDP_RECV_THREADS; i++) {
        pthread_create(&udp_recv_tids[i], NULL, udp_recv_thread, (void *)(intptr_t)recv_socks[i]);
    }
    LOG("dispatcher", "", "udp_recv_threads_created", ",\"count\":%d", UDP_RECV_THREADS);

    /* === FIX #1: Start parser thread pool === */
    pthread_t parser_tids[DISPATCHER_MAX_PARSERS];
    for (int i = 0; i < DISPATCHER_MAX_PARSERS; i++) {
        pthread_create(&parser_tids[i], NULL, parser_thread, (void *)(intptr_t)i);
    }
    LOG("dispatcher", "", "parser_threads_created", ",\"count\":%d", DISPATCHER_MAX_PARSERS);

    LOG("dispatcher", "", "listening",
        ",\"bind_ip\":\"%s\",\"port\":%d,\"report_ip\":\"%s\",\"report_port\":%d,\"heartbeat_port\":%d,\"workers\":%d,\"use_mux\":\"%s\",\"advertised_sip_port\":%d",
        local_ip && local_ip[0] ? local_ip : "0.0.0.0",
        listen_port, report_ip, report_port, g_heartbeat_port, OBD_NUM_WORKERS,
        use_mux ? "yes" : "no",
        use_mux ? g_worker_cfgs[0].sip_mux_port : g_worker_cfgs[0].sip_port);

    /* Main thread just waits for shutdown (all work done by recv/parser/watchdog threads) */
    while (g_running) {
        sleep(1);
    }

    /* Cleanup */
    for (int i = 0; i < UDP_RECV_THREADS; i++)
        close(recv_socks[i]);
    for (int i = 0; i < OBD_NUM_WORKERS; i++)
        close(g_worker_socks[i]);
    dedup_cleanup();
    stop_all_workers();
    if (use_mux)
        mux_cleanup();

    LOG("dispatcher", "", "stopped", "");
}
