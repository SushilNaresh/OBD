# OBD SYSTEM — QUICK REFERENCE SUMMARY
## Token-optimized architecture reference for future analysis

---

## SYSTEM OVERVIEW
- **Name:** OBD (Operator-Based Dialing) SIP Service
- **Type:** High-throughput call collection/testing platform
- **Protocol:** UDP (requests) + SIP (INVITE leg) + UDP (reports)
- **Target:** 10,000 TPS with 10,000 concurrent calls
- **Components:** main.c, dispatcher.c, worker.c, sip_engine.c, dedup.c, udp_report.c, obd.h

---

## ARCHITECTURE FLOW
```
Client A (via UDP 9090)
    ↓ [JSON request: callingMSISDN, calledMSISDN, requestId, destID]
    ↓
Dispatcher Process
    ├─ UDP recv: port 9090
    ├─ JSON parse: extract request fields
    ├─ Dedup check: FNV-1a hash, 65K buckets
    ├─ Worker selection: least-loaded round-robin
    └─ Route: Unix socket to worker
    
Worker Process (100 total, 2 dispatch threads each)
    ├─ Unix socket recv: OBDRequest struct
    ├─ PJSIP engine: create account, make INVITE call
    ├─ SIP leg: state machine (CALLING → EARLY → CONNECTING → DISCONNECTED)
    ├─ Outcome classification: MISSED_CALL, NO_ANSWER, BUSY, etc.
    ├─ Completion queue: lock-free (16K slots)
    ├─ Report thread: drain queue, send UDP to B
    └─ Heartbeat thread: send active call count every 1sec
    
Client B (UDP 9100)
    ↑ [JSON report: requestId, calledMsisdn, deliveryStatus, timestamp]
```

---

## COMPILATION
```bash
# Standard
make tune OBD_NUM_WORKERS=100 OBD_CALLS_PER_WORKER=100

# With PJSIP limit fixes
make tune OBD_NUM_WORKERS=100 OBD_CALLS_PER_WORKER=100 \
    CFLAGS="-DPJSUA_MAX_ACC=10000 -DPJ_IOQUEUE_MAX_HANDLERS=10000"
```

---

## CRITICAL BOTTLENECKS @ 10K TPS

| Rank | Issue | Location | Impact | Fix |
|------|-------|----------|--------|-----|
| 1 | JSON parsing blocks recv loop | dispatcher.c:710 | 70% packet loss | Ring buffer + parser threads |
| 2 | PJSUA_MAX_ACC = 32 global | sip_engine.c | All calls fail after 32 | Set to 10000 in Makefile |
| 3 | MSG_DONTWAIT silent drops | dispatcher.c:720 | Silent request loss | Worker queue + explicit rejects |
| 4 | Single recv thread @ 100% CPU | dispatcher.c | Kernel drops packets | SO_REUSEPORT multi-recv |
| 5 | Account creation latency | sip_engine.c:1040 | 1-2ms overhead per call | Account pooling (future) |
| 6 | Dedup spinlock contention | dedup.c:32 | Minor | Low — acceptable load |

---

## KEY CODE SECTIONS

### Dispatcher Request Path
- **Entry:** dispatcher_run() line 710 (recv loop)
- **Parsing:** json_get() helper (simple string search)
- **Dedup:** dedup_check_and_set() line 32 (spinlock + hash)
- **Routing:** worker selection loop line 700, Unix send line 720

### Worker Dispatch Path
- **Entry:** worker_run() line 70 (dispatch_thread)
- **PJSIP:** sip_engine_dispatch() line 1020
- **Account creation:** pjsua_acc_add() line 1040 (CAN FAIL if PJSUA_MAX_ACC exceeded)
- **Call creation:** pjsua_call_make_call() line 1080

### SIP Engine State Machine
- **Init:** sip_engine_init() line 615 (PJSIP config + transport bind + account pool)
- **Callbacks:** on_call_state() line 870 (CALLING → EARLY → CONNECTING → DISCONNECTED)
- **Outcome:** classify_outcome() line 735 (SIP status → OBDReport outcome enum)
- **Cleanup:** finish_call() line 755 (account delete + report push)

### Completion Queue
- **Type:** lock-free MPSC ring (OPT2 in code comments)
- **Size:** 16,384 slots (obd.h line 41)
- **Push:** sip_engine.c line 773 (lfq_push)
- **Pop:** worker.c line 95 (report_thread drains + sends UDP)

### Report Sender
- **Entry:** udp_report_send() line 20 (udp_report.c)
- **Format:** JSON to client B UDP port 9100
- **Outcome mapping:** MISSED_CALL → "SUCCESS", NO_ANSWER → "FAILED", etc.

---

## PERFORMANCE BASELINE

| Metric | Value @ 10K TPS | Status |
|--------|-----------------|--------|
| Dispatcher CPU | 100% (bottleneck) | 🔴 |
| Worker CPU per instance | 15-20% (idle) | ✓ |
| UDP buffer (16MB) | 6.2 sec backup | ✓ |
| Worker queue depth | ~100-500 (varies) | ✓ |
| Dedup bucket collisions | ~153/65K | ✓ |
| JSON parse latency | 10-50µs per packet | 🟡 |
| Account creation latency | 1-2ms per call | 🟡 |
| Account exhaustion | After 32 concurrent | 🔴 |

---

## FIX IMPLEMENTATIONS

### FIX #1: Ring Buffer + Parser Threads
**Problem:** JSON parsing blocks UDP recv at 10K TPS
**Solution:** 
- Allocate 4K-slot ring buffer
- Separate recv thread (just memcpy)
- 4-8 parser threads (do JSON, routing)
**Gain:** Dispatcher CPU from 100% → 15%, throughput 2-3K → 10K+ TPS

**Code changes:**
- dispatcher.c: Add ring structure + init/push/pop functions (lines ~45, 300)
- dispatcher.c: New udp_recv_thread() + parser_thread() (lines ~550, 600)
- dispatcher.c: dispatcher_run() replace main loop with thread spawn (line ~730)

### FIX #2: Worker Queue + Explicit Rejects
**Problem:** MSG_DONTWAIT drops are silent (no feedback to client)
**Solution:**
- Per-worker lock-free queue (8K slots)
- Queued push attempts before fallback to Unix socket
- Explicit backpressure (NACK response) if queue full

**Code changes:**
- dispatcher.c: Add WorkerQueue struct + push/pop functions (lines ~140, 350)
- dispatcher.c: Initialize in dispatcher_run() (line ~735)
- parser_thread(): Try queue first, NACK if full (line ~620)

### FIX #3: PJSUA_MAX_ACC Limit
**Problem:** Default compiled as 32, but need 10,000
**Solution:** Override at compile-time via Makefile
```makefile
CFLAGS += -DPJSUA_MAX_ACC=10000 -DPJ_IOQUEUE_MAX_HANDLERS=10000
```

**Code changes:**
- sip_engine.c: Add #ifndef guards (line ~20)
- sip_engine_init(): Log actual compiled limits + warning if too low (line ~620)

### FIX #4: SO_REUSEPORT Multi-Recv
**Problem:** Single UDP recv thread @ 100% CPU
**Solution:** 4 threads on same port (kernel load-balances packets)

**Code changes:**
- dispatcher.c: Create N sockets with SO_REUSEPORT flag (line ~750)
- dispatcher_run(): Launch udp_recv_thread per socket

### FIX #5: Backpressure Signaling
**Problem:** No flow control — upstream never knows system is full
**Solution:** Send explicit NACK with retry_after hint

**Code changes:**
- parser_thread(): If no worker available, craft + send NACK JSON (line ~620)

---

## METRICS TO MONITOR

**Dispatcher:**
- `ring_buffer_drops` — if non-zero, increase ring size
- `parser_thread` utilization — should be <80% each
- UDP recv rate (packets/sec) vs parser rate

**Workers:**
- `active_calls` per worker — should not exceed OBD_CALLS_PER_WORKER
- `slab_alloc_failed` — means worker out of context slots
- `pjsua_acc_add_failed` — means PJSUA_MAX_ACC too low

**System:**
- Dispatcher CPU — should be <50% after fixes
- Memory (RSS) per worker — watch for leaks (should stabilize)
- Lost packets — from kernel stats, should be <0.1% at 10K TPS

---

## COMMON ISSUES & RESOLUTIONS

### Issue: All calls fail with OUTCOME_NETWORK_DOWN (503)
**Root cause:** PJSUA_MAX_ACC limit (default 32)
**Fix:** Rebuild with `-DPJSUA_MAX_ACC=10000`
**Evidence:** Log "pjsua_acc_add_failed" spikes

### Issue: Dispatcher at 100% CPU, packet loss
**Root cause:** JSON parsing in recv loop
**Fix:** Ring buffer + parser threads (FIX #1)
**Evidence:** "ring_buffer_full" logs, high syscall rate

### Issue: "route_failed" in logs, silent requests
**Root cause:** Worker Unix socket buffer overflow
**Fix:** Worker queue + explicit backpressure (FIX #2)
**Evidence:** "worker_queue_full" or "route_failed errno=105"

### Issue: Uneven load across workers
**Root cause:** Least-loaded selection stale (heartbeat lag)
**Fix:** Increase heartbeat frequency from 1sec to 100ms (minor)
**Evidence:** Some workers @ 80% utilization, others @ 20%

---

## QUICK TEST COMMANDS

```bash
# Compile with all fixes
make tune OBD_NUM_WORKERS=100 OBD_CALLS_PER_WORKER=100 \
    CFLAGS="-DPJSUA_MAX_ACC=10000 -DPJ_IOQUEUE_MAX_HANDLERS=10000"

# Test 1K TPS (baseline)
./send_udp_tps.sh 1000 60

# Test 5K TPS (moderate)
./send_udp_tps.sh 5000 60

# Test 10K TPS (full load)
./send_udp_tps.sh 10000 60

# Test sustained (5 min @ 10K)
./send_udp_tps.sh 10000 300

# Check logs for bottlenecks
tail -f /tmp/obd.log | grep -E "(bottleneck|overflow|failed|drop)"
```

---

## EXPECTED RESULTS AFTER ALL FIXES

| Metric | Before | After |
|--------|--------|-------|
| Max TPS sustained | 2-3K | 10K+ |
| Dispatcher CPU @ 10K TPS | 100% | 15-20% |
| Silent packet loss | Yes, ~70% | No, explicit rejects |
| Account creation failures | Yes, >32 calls | No, up to 10K |
| Worker socket drops | Yes, random | No, explicit queue mgmt |

---

## FUTURE ENHANCEMENTS (Post-Phase 3)

1. **Binary protocol** instead of JSON (20x faster parsing)
2. **Account pooling** — pre-alloc accounts at startup, reuse
3. **Smarter dedup** — xHash instead of FNV-1a
4. **Dynamic worker scaling** — auto-spawn workers on high load
5. **Persistent outbound flow state** — MUX table survives worker restart
6. **Telemetry streaming** — push metrics instead of pull

---

## FILE DEPENDENCIES

```
obd.h
  ├── shared types: OBDRequest, OBDReport, CallOutcome
  ├── constants: OBD_NUM_WORKERS, OBD_CALLS_PER_WORKER, OBD_COMPQ_SIZE
  ├── WorkerConfig struct (sip_port, sip_mux_port, default_proxy, etc.)
  └── LFQueue (lock-free completion queue)

main.c
  └── parses config → builds WorkerConfig → forks workers → becomes dispatcher entry point

dispatcher.c
  ├── UDP recv + JSON parse + dedup + routing
  ├── Worker health monitoring + watchdog
  ├── SIP-MUX (optional, if use_mux="yes")
  └── Heartbeat + worker restart logic

worker.c
  ├── Recv from dispatcher (Unix socket)
  ├── Thread pool: dispatch (2), report (4), heartbeat (1)
  └── PJSIP initialization

sip_engine.c
  ├── PJSUA library interface
  ├── Call state machine + callbacks
  ├── Outcome classification
  ├── Slab pool for call contexts
  └── Account management (per-worker)

udp_report.c
  └── Format + send JSON reports to client B

dedup.c
  ├── FNV-1a hash + spinlock per bucket
  └── 65K buckets, 120sec TTL entries
```

---

## PAPER TRAIL

1. **OBD_PERFORMANCE_ANALYSIS.md** — Detailed bottleneck analysis with math
2. **OBD_RECOMMENDED_FIXES.md** — Architecture solutions + pseudo-code
3. **OBD_CODE_CHECKLIST.md** — Exact line numbers for implementation
4. **OBD_QUICK_REFERENCE.md** — This file

Use **#1** for understanding why, **#2** for what to do, **#3** for where to make changes.
