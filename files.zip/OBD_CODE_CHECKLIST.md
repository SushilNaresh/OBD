# OBD CODE MODIFICATION CHECKLIST
## Exact locations for implementing performance fixes

---

## FIX #1: RING BUFFER + PARSER THREADS

### File: dispatcher.c

**Location 1: After includes (line ~45)**
```c
/* Add after #include "obd.h" */

#define DISPATCHER_RING_SIZE 4096
#define DISPATCHER_MAX_PARSERS 8

typedef struct {
    char        payload[4096];
    int         len;
    uint32_t    src_ip;
    uint16_t    src_port;
    time_t      arrival_time;
} DispatcherRingSlot;

typedef struct {
    DispatcherRingSlot slots[DISPATCHER_RING_SIZE];
    _Atomic uint64_t head;
    _Atomic uint64_t tail;
} DispatcherRing;

static DispatcherRing g_disp_ring;
static _Atomic int g_disp_ring_drops = 0;  /* Metric: how many packets dropped due to ring full */
```

**Location 2: After mux_cleanup() (~line 286)**
```c
/* Add ring buffer functions */

static void disp_ring_init(void)
{
    memset(&g_disp_ring, 0, sizeof(g_disp_ring));
    atomic_store_explicit(&g_disp_ring.head, 0, memory_order_relaxed);
    atomic_store_explicit(&g_disp_ring.tail, 0, memory_order_relaxed);
}

static int disp_ring_push(const char *payload, int len, uint32_t src_ip, uint16_t src_port)
{
    if (len > 4095) len = 4095;
    
    uint64_t pos = atomic_fetch_add_explicit(&g_disp_ring.head, 1, memory_order_relaxed);
    uint64_t idx = pos & (DISPATCHER_RING_SIZE - 1);
    uint64_t tail = atomic_load_explicit(&g_disp_ring.tail, memory_order_relaxed);
    
    if (pos - tail >= DISPATCHER_RING_SIZE) {
        atomic_fetch_add(&g_disp_ring_drops, 1);
        return -1;
    }
    
    memcpy(g_disp_ring.slots[idx].payload, payload, len);
    g_disp_ring.slots[idx].len = len;
    g_disp_ring.slots[idx].src_ip = src_ip;
    g_disp_ring.slots[idx].src_port = src_port;
    g_disp_ring.slots[idx].arrival_time = time(NULL);
    
    return 0;
}

static int disp_ring_pop(DispatcherRingSlot *slot)
{
    uint64_t pos = atomic_load_explicit(&g_disp_ring.tail, memory_order_relaxed);
    uint64_t idx = pos & (DISPATCHER_RING_SIZE - 1);
    uint64_t head = atomic_load_explicit(&g_disp_ring.head, memory_order_acquire);
    
    if (pos >= head)
        return -1;
    
    memcpy(slot, &g_disp_ring.slots[idx], sizeof(*slot));
    atomic_fetch_add_explicit(&g_disp_ring.tail, 1, memory_order_relaxed);
    return 0;
}
```

**Location 3: UDP recv thread (~line 550, REPLACE dispatch loop)**
```c
/* Replace the main recv loop starting at line ~710 with: */

static void *udp_recv_thread(void *arg)
{
    int sock = (intptr_t)arg;
    char buf[4096];
    
    LOG("dispatcher", "", "udp_recv_thread_started", "");
    
    while (g_running) {
        struct sockaddr_in src;
        socklen_t slen = sizeof(src);
        ssize_t n = recvfrom(sock, buf, sizeof(buf) - 1, 0, (struct sockaddr *)&src, &slen);
        
        if (n <= 0) {
            if (errno == EINTR) continue;
            break;
        }
        
        if (disp_ring_push(buf, (int)n, src.sin_addr.s_addr, ntohs(src.sin_port)) != 0) {
            LOG("dispatcher", "", "ring_buffer_full", 
                ",\"drops_total\":%d", atomic_load(&g_disp_ring_drops));
        }
    }
    
    LOG("dispatcher", "", "udp_recv_thread_stopped", "");
    return NULL;
}
```

**Location 4: Parser thread (~line 600)**
```c
static void *parser_thread(void *arg)
{
    int parser_id = (intptr_t)arg;
    DispatcherRingSlot slot;
    
    LOG("dispatcher", "", "parser_thread_started", ",\"parser_id\":%d", parser_id);
    
    while (g_running) {
        if (disp_ring_pop(&slot) != 0) {
            usleep(100);
            continue;
        }
        
        /* === JSON PARSING SECTION === */
        OBDRequest req;
        memset(&req, 0, sizeof(req));
        req.timeout_sec = OBD_DEFAULT_TIMEOUT;
        
        json_get(slot.payload, "callingMSISDN", req.calling_msisdn, sizeof(req.calling_msisdn));
        json_get(slot.payload, "calledMSISDN", req.called_msisdn, sizeof(req.called_msisdn));
        json_get(slot.payload, "requestId", req.request_id, sizeof(req.request_id));
        json_get(slot.payload, "destID", req.dest_id, sizeof(req.dest_id));
        
        char timeout_str[16] = "";
        if (json_get(slot.payload, "timeout", timeout_str, sizeof(timeout_str)) == 0 && timeout_str[0]) {
            char *end;
            long val = strtol(timeout_str, &end, 10);
            if (end != timeout_str && *end == '\0' && val > 0 && val <= INT_MAX)
                req.timeout_sec = (int)val;
        }
        
        if (!req.called_msisdn[0] || !req.request_id[0]) continue;
        
        /* === DEDUP CHECK === */
        if (dedup_check_and_set(req.request_id)) {
            LOG("dispatcher", req.request_id, "dedup_drop", "");
            continue;
        }
        
        /* === WORKER SELECTION === */
        int w = -1;
        int min_load = INT_MAX;
        time_t current_time = time(NULL);
        
        for (int i = 0; i < OBD_NUM_WORKERS; i++) {
            int idx = (g_next_worker + i) % OBD_NUM_WORKERS;
            if (g_worker_pids[idx] > 0 && current_time - g_worker_heartbeat[idx] <= OBD_WATCHDOG_TIMEOUT) {
                int load = atomic_load(&g_worker_inflight[idx]);
                if (load < min_load) {
                    min_load = load;
                    w = idx;
                }
            }
        }
        
        if (w == -1) {
            for (int i = 0; i < OBD_NUM_WORKERS; i++) {
                int idx = (g_next_worker + i) % OBD_NUM_WORKERS;
                if (g_worker_pids[idx] > 0) {
                    w = idx;
                    g_next_worker = (idx + 1) % OBD_NUM_WORKERS;
                    break;
                }
            }
        }
        
        /* === ROUTING TO WORKER === */
        if (w != -1) {
            g_next_worker = (w + 1) % OBD_NUM_WORKERS;
            ssize_t sent = send(g_worker_socks[w], &req, sizeof(req), MSG_DONTWAIT);
            if (sent > 0) {
                atomic_fetch_add(&g_worker_inflight[w], 1);
                LOG("dispatcher", req.request_id, "routed", ",\"worker\":%d,\"inflight\":%d", w, atomic_load(&g_worker_inflight[w]));
            } else {
                int err = errno;
                LOG("dispatcher", req.request_id, "route_failed",
                    ",\"worker\":%d,\"errno\":%d,\"reason\":\"%s\"",
                    w, err, strerror(err));
            }
        } else {
            LOG("dispatcher", req.request_id, "no_workers_available", "");
        }
    }
    
    LOG("dispatcher", "", "parser_thread_stopped", ",\"parser_id\":%d", parser_id);
    return NULL;
}
```

**Location 5: dispatcher_run() changes (~line 730)**

REPLACE this section:
```c
    /* Main recv loop for incoming call command frames */
    char buf[4096];
    while (g_running) {
        struct sockaddr_in src;
        socklen_t slen = sizeof(src);
        ssize_t n = recvfrom(sock, buf, sizeof(buf) - 1, 0,
                             (struct sockaddr *)&src, &slen);
        if (n <= 0) {
            if (errno == EINTR) continue;
            break;
        }
        buf[n] = '\0';
        
        /* Parse JSON ... */
        // ... existing code ...
    }
```

WITH:
```c
    /* Initialize ring buffer */
    disp_ring_init();
    
    /* Start dedicated UDP recv thread */
    pthread_t udp_recv_tid;
    pthread_create(&udp_recv_tid, NULL, udp_recv_thread, (void *)(intptr_t)sock);
    LOG("dispatcher", "", "udp_recv_thread_created", "");
    
    /* Start parser thread pool */
    pthread_t parser_tids[DISPATCHER_MAX_PARSERS];
    for (int i = 0; i < DISPATCHER_MAX_PARSERS; i++) {
        pthread_create(&parser_tids[i], NULL, parser_thread, (void *)(intptr_t)i);
    }
    LOG("dispatcher", "", "parser_threads_created", ",\"count\":%d", DISPATCHER_MAX_PARSERS);
    
    /* Main thread now just waits for shutdown */
    while (g_running) {
        sleep(1);
    }
```

---

## FIX #2: WORKER QUEUE IMPLEMENTATION

### File: dispatcher.c

**Location: After g_worker_inflight definition (~line 140)**
```c
static _Atomic int g_worker_inflight[OBD_NUM_WORKERS];

/* ADD: Worker queues */
#define WORKER_QUEUE_SIZE 8192

typedef struct {
    OBDRequest reqs[WORKER_QUEUE_SIZE];
    _Atomic uint64_t head;
    _Atomic uint64_t tail;
    _Atomic uint64_t pushed_count;    /* Metric */
    _Atomic uint64_t popped_count;    /* Metric */
    _Atomic uint64_t drop_count;      /* Metric */
} WorkerQueue;

static WorkerQueue g_worker_queues[OBD_NUM_WORKERS];
```

**Location: Before watchdog_thread definition (~line 350)**
```c
static void worker_queue_init(void)
{
    for (int i = 0; i < OBD_NUM_WORKERS; i++) {
        memset(&g_worker_queues[i], 0, sizeof(WorkerQueue));
        atomic_store(&g_worker_queues[i].head, 0);
        atomic_store(&g_worker_queues[i].tail, 0);
    }
}

static int worker_queue_push(int worker_id, const OBDRequest *req)
{
    if (worker_id < 0 || worker_id >= OBD_NUM_WORKERS)
        return -1;
    
    WorkerQueue *q = &g_worker_queues[worker_id];
    uint64_t head = atomic_load_explicit(&q->head, memory_order_relaxed);
    uint64_t tail = atomic_load_explicit(&q->tail, memory_order_acquire);
    
    if (head - tail >= WORKER_QUEUE_SIZE) {
        atomic_fetch_add(&q->drop_count, 1);
        return -1;
    }
    
    uint64_t idx = head & (WORKER_QUEUE_SIZE - 1);
    memcpy(&q->reqs[idx], req, sizeof(*req));
    atomic_fetch_add_explicit(&q->head, 1, memory_order_release);
    atomic_fetch_add(&q->pushed_count, 1);
    return 0;
}

static int worker_queue_pop(int worker_id, OBDRequest *req)
{
    if (worker_id < 0 || worker_id >= OBD_NUM_WORKERS)
        return -1;
    
    WorkerQueue *q = &g_worker_queues[worker_id];
    uint64_t tail = atomic_load_explicit(&q->tail, memory_order_relaxed);
    uint64_t head = atomic_load_explicit(&q->head, memory_order_acquire);
    
    if (tail >= head)
        return -1;
    
    uint64_t idx = tail & (WORKER_QUEUE_SIZE - 1);
    memcpy(req, &q->reqs[idx], sizeof(*req));
    atomic_fetch_add_explicit(&q->tail, 1, memory_order_release);
    atomic_fetch_add(&q->popped_count, 1);
    return 0;
}

/* Watchdog reports queue metrics */
static void worker_queue_report_metrics(int worker_id)
{
    WorkerQueue *q = &g_worker_queues[worker_id];
    uint64_t pushed = atomic_load(&q->pushed_count);
    uint64_t popped = atomic_load(&q->popped_count);
    uint64_t drops = atomic_load(&q->drop_count);
    
    LOG("dispatcher", "", "worker_queue_metrics",
        ",\"worker\":%d,\"pushed\":%lu,\"popped\":%lu,\"drops\":%lu,\"pending\":%lu",
        worker_id, pushed, popped, drops, pushed - popped - drops);
}
```

**Location: dispatcher_run() startup (~line 735)**
```c
    /* Initialize worker queues */
    worker_queue_init();
    LOG("dispatcher", "", "worker_queues_init", ",\"workers\":%d,\"queue_size\":%d", 
        OBD_NUM_WORKERS, WORKER_QUEUE_SIZE);
```

**Location: In parser_thread where we route to worker (~line 625)**
```c
        /* REPLACE this section: */
        if (w != -1) {
            ssize_t sent = send(g_worker_socks[w], &req, sizeof(req), MSG_DONTWAIT);
            if (sent > 0) {
                atomic_fetch_add(&g_worker_inflight[w], 1);
                LOG("dispatcher", req.request_id, "routed", ...);
            } else {
                LOG("dispatcher", req.request_id, "route_failed", ...);
            }
        }
        
        /* WITH this: */
        if (w != -1) {
            /* Try queue first (new path) */
            if (worker_queue_push(w, &req) == 0) {
                atomic_fetch_add(&g_worker_inflight[w], 1);
                LOG("dispatcher", req.request_id, "queued", ",\"worker\":%d", w);
            } else {
                /* Queue full — explicit backpressure */
                LOG("dispatcher", req.request_id, "worker_queue_full", 
                    ",\"worker\":%d,\"queue_size\":%d", w, WORKER_QUEUE_SIZE);
                
                /* Try direct Unix socket as fallback */
                ssize_t sent = send(g_worker_socks[w], &req, sizeof(req), MSG_DONTWAIT);
                if (sent > 0) {
                    atomic_fetch_add(&g_worker_inflight[w], 1);
                    LOG("dispatcher", req.request_id, "routed_direct", ",\"worker\":%d", w);
                } else {
                    LOG("dispatcher", req.request_id, "route_all_full", ",\"worker\":%d", w);
                }
            }
        }
```

---

## FIX #3: PJSUA_MAX_ACC LIMIT

### File: sip_engine.c

**Location: At top after includes (~line 20)**
```c
/* Add compile-time override for PJSIP limits */
#ifndef PJSUA_MAX_ACC
#define PJSUA_MAX_ACC 10000
#endif

#ifndef PJSUA_MAX_CALLS
#define PJSUA_MAX_CALLS 100
#endif

#ifndef PJ_IOQUEUE_MAX_HANDLERS
#define PJ_IOQUEUE_MAX_HANDLERS 10000
#endif
```

**Location: In sip_engine_init() (~line 620)**
```c
    /* Add diagnostic logging of compiled limits */
    LOG(g_tag, "", "pjsip_compile_limits",
        ",\"PJSUA_MAX_CALLS\":%d,\"PJSUA_MAX_ACC\":%d,\"PJ_IOQUEUE_MAX_HANDLERS\":%d",
        PJSUA_MAX_CALLS, PJSUA_MAX_ACC, PJ_IOQUEUE_MAX_HANDLERS);
    
    if (PJSUA_MAX_ACC < 1000) {
        LOG(g_tag, "", "warning_low_account_limit",
            ",\"compiled\":%d,\"recommended\":10000,\"call_this_out_to_devops\":",
            PJSUA_MAX_ACC);
    }
```

### File: main.c

**Location: Makefile (create if doesn't exist)**
```makefile
# Add to compiler flags
CFLAGS += -DPJSUA_MAX_ACC=10000 \
          -DPJSUA_MAX_CALLS=100 \
          -DPJ_IOQUEUE_MAX_HANDLERS=10000
```

---

## FIX #4: BACKPRESSURE SIGNALING

### File: dispatcher.c

**Location: In parser_thread, if no worker available (~line 620)**
```c
        /* Original: */
        if (w == -1) {
            LOG("dispatcher", req.request_id, "no_workers_available", "");
        }
        
        /* REPLACE WITH: */
        if (w == -1) {
            /* Send explicit NACK to client */
            struct sockaddr_in src;
            src.sin_family = AF_INET;
            src.sin_addr.s_addr = slot.src_ip;
            src.sin_port = htons(slot.src_port);
            
            char nack[512];
            snprintf(nack, sizeof(nack),
                "{\"requestId\":\"%s\",\"status\":\"BACKPRESSURE\",\"reason\":\"no_workers_available\",\"retry_after_ms\":1000}",
                req.request_id);
            
            sendto(sock, nack, strlen(nack), 0, (struct sockaddr *)&src, sizeof(src));
            LOG("dispatcher", req.request_id, "backpressure_nack_sent", 
                ",\"client\":%pI4", &src.sin_addr);
        }
```

---

## FIX #5: MULTI-THREADED UDP RECEIVE (SO_REUSEPORT)

### File: dispatcher.c

**Location: dispatcher_run() socket creation (~line 750)**
```c
    /* REPLACE: */
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    
    /* WITH: */
    #define UDP_RECV_THREADS 4
    int recv_socks[UDP_RECV_THREADS];
    
    for (int i = 0; i < UDP_RECV_THREADS; i++) {
        recv_socks[i] = socket(AF_INET, SOCK_DGRAM, 0);
        if (recv_socks[i] < 0) {
            perror("socket");
            exit(1);
        }
        
        int reuse = 1;
        setsockopt(recv_socks[i], SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
#ifdef SO_REUSEPORT
        setsockopt(recv_socks[i], SOL_SOCKET, SO_REUSEPORT, &reuse, sizeof(reuse));
#endif
        
        int rcvbuf = 16 * 1024 * 1024;
        setsockopt(recv_socks[i], SOL_SOCKET, SO_RCVBUF, &rcvbuf, sizeof(rcvbuf));
        
        struct sockaddr_in addr;
        memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        addr.sin_port = htons(listen_port);
        addr.sin_addr.s_addr = INADDR_ANY;
        
        if (bind(recv_socks[i], (struct sockaddr *)&addr, sizeof(addr)) < 0) {
            LOG("dispatcher", "", "bind_failed",
                ",\"socket\":%d,\"port\":%d,\"reason\":\"%s\"",
                i, listen_port, strerror(errno));
            exit(1);
        }
    }
    
    /* Start N UDP recv threads (one per socket) */
    for (int i = 0; i < UDP_RECV_THREADS; i++) {
        pthread_t tid;
        pthread_create(&tid, NULL, udp_recv_thread, (void *)(intptr_t)recv_socks[i]);
        LOG("dispatcher", "", "recv_socket_created", ",\"socket_id\":%d,\"port\":%d", i, listen_port);
    }
```

---

## FIX #6: WORKER QUEUE CONSUMER IN worker.c

### File: worker.c

**Location: Replace dispatch_thread() (~line 70)**
```c
static void *dispatch_thread(void *arg)
{
    (void)arg;
    OBDRequest req;
    
    pj_thread_desc desc;
    pj_thread_t *thread;
    pj_thread_register("dispatch_q", desc, &thread);
    
    int queue_pops = 0;
    int unix_recvs = 0;
    
    while (w_running) {
        /* Try queue first */
        if (worker_queue_pop(w_cfg.worker_id, &req) == 0) {
            queue_pops++;
            LOG(w_tag, req.request_id, "dispatch_from_queue", "");
            sip_engine_dispatch(&req);
        } else {
            /* Fallback: try Unix socket for backward compat */
            ssize_t n = recv(w_unix_sock, &req, sizeof(req), MSG_DONTWAIT);
            if (n == sizeof(req)) {
                unix_recvs++;
                LOG(w_tag, req.request_id, "dispatch_from_unix", "");
                sip_engine_dispatch(&req);
            } else {
                /* Nothing to do — sleep briefly */
                usleep(100);
            }
        }
        
        /* Every 10K operations, log metrics */
        if ((queue_pops + unix_recvs) % 10000 == 0) {
            LOG(w_tag, "", "dispatch_metrics",
                ",\"queue_pops\":%d,\"unix_recvs\":%d,\"ratio\":%.2f",
                queue_pops, unix_recvs, 
                (double)queue_pops / (queue_pops + unix_recvs + 1));
        }
    }
    return NULL;
}
```

---

## TESTING CHECKLIST

After implementing all fixes, run:

```bash
# Test 1: Compile check
make tune OBD_NUM_WORKERS=100 OBD_CALLS_PER_WORKER=100
# Should not fail, especially on PJSUA_MAX_ACC warnings

# Test 2: Startup validation
./obd --config test.conf
# Should show:
#   - "ring_buffer_init"
#   - "worker_queues_init"
#   - "parser_threads_created"
#   - "pjsip_compile_limits" with high account count

# Test 3: Baseline load (1K TPS, 60 sec)
./send_udp_tps.sh 1000 60
# Expected: 100% SUCCESS, <1% packet loss

# Test 4: Moderate load (5K TPS, 60 sec)
./send_udp_tps.sh 5000 60
# Expected: 99%+ SUCCESS, <0.5% packet loss

# Test 5: Full load (10K TPS, 60 sec)
./send_udp_tps.sh 10000 60
# Expected: 95%+ SUCCESS (backpressure NACKs OK), <5% total loss

# Test 6: Sustained (10K TPS, 300 sec)
./send_udp_tps.sh 10000 300
# Expected: stable queue depths, no memory leaks, CPU <50%
```

---

## METRICS TO MONITOR POST-DEPLOYMENT

Add to watchdog output or separate monitoring thread:

```
Dispatcher metrics:
  - UDP recv rate (packets/sec)
  - Ring buffer depth (current items)
  - Ring buffer drops (total count)
  - Parser thread utilization

Worker metrics:
  - Queue depth per worker
  - Queue push/pop rates
  - Queue drop count
  - Active call count
  - Account pool available

System metrics:
  - CPU usage (dispatcher, workers, total)
  - Memory (RSS, VSZ growth)
  - Packet loss (kernel drops)
```

---

## ROLLBACK PLAN

If performance worse after changes:

1. Disable ring buffer (revert to direct recv)
2. Disable worker queues (revert to MSG_DONTWAIT)
3. Reduce parser threads from 8 → 4 → 1
4. Check PJSUA_MAX_ACC was actually compiled with new limit

---

See: **OBD_PERFORMANCE_ANALYSIS.md** for detailed reasoning
